@echo off
cd /d "%~dp0"
call setup_iris.bat
